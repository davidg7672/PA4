/*
David Sosa Vidal
CPSC 122
Professor Jacob Shea
Programming Assignment 4, Structs
Main Function
*/

/********************************************
TASK 2 OUTPUT DOESN'T FORMAT PROPERLY
********************************************/

#include "Structs.h"

int main(int argc, char *argv[]) {
    
    // Task one function, computes everything
    taskOne();
    
    // Task Two function, computes everything
    taskTwo(argv);
    
    return 0;
}
